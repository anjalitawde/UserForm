import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../model/User';
import { DataTransferService } from '../service/data-transfer.service';

@Component({
    // moduleId: module.id,
    selector: 'user-list',
    templateUrl: 'user-list.component.html',
    styleUrls: ['user-list.component.scss']
})
export class UserListComponent {
    users: User[];
    constructor(private router: Router, private dataTransferService: DataTransferService) {
        this.users = this.dataTransferService.getAllUsers();
    }
    ShowDetail() {
        this.router.navigate(['/userDetail']);

    }
     AddUser() {
        this.router.navigate(['/']);

    }
}
