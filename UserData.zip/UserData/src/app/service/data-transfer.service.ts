import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataTransferService {
  private users: any[];
  constructor() {
    //Some predefined data
    this.users = [
      {
        DOB: "2019-06-03",
        department: "Developer",
        email: "user1@gmail.com",
        firstName: "User",
        gender: "female",
        lastName: "1",
        phone: 9123456789
      }, {
        DOB: "2019-04-10",
        department: "QA",
        email: "user2@gmail.com",
        firstName: "User ",
        gender: "female",
        lastName: "2",
        phone: 9124365879,
      }, {
        DOB: "2019-03-06",
        department: "IT",
        email: "user3@gmail.com",
        firstName: "User",
        gender: "male",
        lastName: "3",
        phone: 8261734726
      }, {
        DOB: "2019-03-04",
        department: "BD",
        email: "user4@gmail.com",
        firstName: "User",
        gender: "male",
        lastName: "4",
        phone: 9876543210
      }
    ]
  };
  setUsers(data: any) {
    this.users = data;
  }
  addUser(data: any) {
    this.users.push(data);
  }
  getAllUsers() {
    return this.users;
  }
}
