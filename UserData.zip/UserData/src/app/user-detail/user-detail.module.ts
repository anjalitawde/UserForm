// Angular Imports
import { NgModule } from '@angular/core';

// This Module's Components
import { UserDetailComponent } from './user-detail.component';

@NgModule({
    imports: [

    ],
    declarations: [
        UserDetailComponent,
    ],
    exports: [
        UserDetailComponent,
    ]
})
export class UserDetailModule {

}
