import { Component, Input } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../model/User';

@Component({
    //  moduleId: module.id,
    selector: 'user-detail',
    templateUrl: 'user-detail.component.html',
    styleUrls: ['user-detail.component.scss']
})
export class UserDetailComponent {
  @Input() user:User;
    constructor(private router: Router) {
    }
    GoToBack() {
        this.router.navigate(['/userList']);
    }
}
