// Angular Imports
import { NgModule } from '@angular/core';
import { FormsModule ,ReactiveFormsModule}   from '@angular/forms';

// This Module's Components
import { InputFormComponent } from './input-form.component';

@NgModule({
    imports: [
        FormsModule , 
        ReactiveFormsModule
    ],
    declarations: [
        InputFormComponent,
    ],
    exports: [
        InputFormComponent,
    ]
})
export class InputFormModule {

}
