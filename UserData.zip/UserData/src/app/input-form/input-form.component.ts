import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, FormBuilder, Validators, EmailValidator } from '@angular/forms';
import { DataTransferService } from '../service/data-transfer.service';

@Component({
    //  moduleId: module.id,
    selector: 'input-form',
    templateUrl: 'input-form.component.html',
    styleUrls: ['input-form.component.scss']
})
export class InputFormComponent {
    constructor(private router: Router, private dataTransferService: DataTransferService, private fb: FormBuilder) {
        this.createForm();
    }

    angForm: FormGroup;

    createForm() {
        this.angForm = this.fb.group({
            firstName: ['', Validators.required],
            lastName: ['', Validators.required],
            phone: ['', [Validators.required, Validators.pattern('[6-9]\\d{9}')]],
            email: ['', [Validators.required, Validators.pattern('^[A-Za-z0-9._%+-]+@[A-Za-z0-9._%+-]{2,}[.][A-Za-z]{2,}$')]],
            gender: ['', Validators.required],
            DOB: ['', Validators.required],
            department: ['', Validators.required]
        });
    }

    // loginForm = new FormGroup({
    //     firstName: new FormControl(''),
    //     lastName: new FormControl(''),
    //     email: new FormControl(''),
    //     department: new FormControl(''),
    //     DOB: new FormControl(''),
    //     gender: new FormControl(''),
    //     image: new FormControl(''),
    //     phone: new FormControl('')
    // });
    saveData(data: any) {
        //console.log(this.angForm.value);
        //  this.loginForm.value.image = this.image[0];
        this.dataTransferService.addUser(this.angForm.value);
        this.router.navigate(['/userList']);
    }
    ShowListOfAllEntries() {
        this.router.navigate(['/userList']);

    }
    // storeImagePath(event) {
    //     this.image = event.target.files;
    // }
}
