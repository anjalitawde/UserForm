export class User {
    firstName: string;
    lastName: string;
    email:string;
    DOB:string;
    department:string;
    gender:string;
    phone:number;
  }